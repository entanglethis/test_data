#!/usr/bin/env python3
# mock_solver.py
#
# Mock challenge solver for Subnet 63 pipeline testing.
#
# Usage: python mock_solver.py <challenge_id> <JSON-encoded mock_challenge.Problem>
#
# Signs a time-based payload with the Ed25519 private key from
# ENIGMA_MOCK_PRIVATE_KEY env var. The private key is passed at container
# runtime, never baked into the Docker image.
#
# Writes results to OUTPUT_DIR (or /output/) as result.json, stdout.log,
# solve_info.json.

from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import time
from typing import *

from sqlalchemy.engine import ConnectArgsType

from enigma_challenge.mock_challenge import Solution
from enigma_challenge.mock_challenge import Problem, sign_mock_payload

CONTAINER_SOLUTION_DIRNAME = "solution_artifacts"


def _printlog(msg: str, logfile: Optional[TextIO]) -> None:
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    line = f"[{timestamp}] {msg}\n"
    print(line, end="", flush=True)
    if logfile is not None:
        logfile.write(line)
        logfile.flush()


def main() -> None:
    output_dir = Path(os.environ.get("OUTPUT_DIR", "/output"))
    solution_dir = output_dir / CONTAINER_SOLUTION_DIRNAME
    log_file_path = output_dir / "stdout.log"
    solve_info_path = solution_dir / "solve_info.json"
    output_file_path = solution_dir / "result.json"
    

    if len(sys.argv) != 3:
        print("Missing args: <challenge_id> <JSON-encoded mock_challenge.Problem>")
        sys.exit(1)

    challenge_id = sys.argv[1].strip()
    try:
        problem = Problem.from_json(sys.argv[2].strip())
    except Exception as err:
        print(f"Error parsing input problem:\n{err}")
        sys.exit(1)

    # private_key_hex = os.environ.get("ENIGMA_MOCK_PRIVATE_KEY")
    private_key_hex = "7b4e2f00b6d6ff2e338b42b2bf599201d285f1fddd4f7b3b99a824fdd36cc8dc"
    if not private_key_hex:
        print("Error: ENIGMA_MOCK_PRIVATE_KEY env var not set")
        sys.exit(1)

    output_dir.mkdir(exist_ok=True)
    timestamp_start = datetime.now(timezone.utc).isoformat()

    with log_file_path.open("w") as logf:
        log = lambda msg: _printlog(msg, logfile=logf)
        log(f"Starting mock challenge: {challenge_id}")
        log(f"Difficulty: {problem.difficulty}")

        try:
            solution = sign_mock_payload(private_key_hex)
            log("Successfully signed payload")
        except Exception as err:
            log(f"Error signing payload: {err}")
            solution = Solution("error", None, None)

        solution.to_json_file(output_file_path)
        log(f"Result written to {output_file_path}")

    with solve_info_path.open("w") as outf:
        info = {
            "solution_status": solution.status,
            "challenge_id": challenge_id,
            "timestamp_utc": timestamp_start,
        }
        json.dump(info, outf)

    sys.exit(0 if solution.status == "success" else 1)


if __name__ == "__main__":
    main()
