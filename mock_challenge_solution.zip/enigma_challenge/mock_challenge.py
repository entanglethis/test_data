"""
Challenge interface for the mock (plumbing test) challenge.

The mock challenge uses Ed25519 signatures to verify that only authorized
parties can produce valid solutions. The solver signs a time-based payload
with a private key; the validator verifies the signature against a known
public key and checks that the timestamp is within the validity window.

The private key is never included in source code or Docker images. It lives
on the miner's machine as an environment variable.
"""

from __future__ import annotations
from dataclasses import dataclass
import json
import logging
import time
from typing import *

from .utils.timing import timed
from . import Challenge, Serde

_logger = logging.getLogger(__name__)

VALIDITY_WINDOW_SECONDS = 600  # 10 minutes

# Default public key for mock challenge verification. Validators use this
# unless overridden. The corresponding private key is held by the team.
DEFAULT_PUBLIC_KEY_HEX = "27705e2d84ec5fb03bd247097afb356691592e7da30543f83efc9632f799d980"


@dataclass
class Problem(Serde):
    """
    Problem instance for the mock challenge.

    The mock challenge has no computational problem to solve. The problem
    is simply a container for the difficulty label.

    Attributes:
        difficulty (int): Difficulty label (unused, present for interface
            consistency).
    """
    difficulty: int


@dataclass
class Solution(Serde):
    """
    Solution to the mock challenge.

    The solution carries an Ed25519 signature over a JSON payload containing
    a timestamp. The validator verifies the signature and checks that the
    timestamp falls within the validity window.

    Attributes:
        status (str): Final solution status.
        signature (str): Hex-encoded Ed25519 signature over ``payload``.
        payload (str): JSON string containing at least ``{"ts": <unix_epoch>}``.
    """
    status: str
    signature: Optional[str]
    payload: Optional[str]


@dataclass
class Verif(Serde):
    """
    Verification data for the mock challenge.

    Attributes:
        public_key_hex (str): Hex-encoded Ed25519 public key.
    """
    public_key_hex: str


@dataclass
class MockChallenge(Challenge[Problem, Solution, Verif]):
    """
    Mock challenge for testing the validator/miner pipeline.

    This challenge verifies that a solution was produced by a party holding
    the Ed25519 private key corresponding to ``public_key_hex``, and that
    the signed timestamp is recent (within ``VALIDITY_WINDOW_SECONDS``).

    Attributes:
        difficulty (int): Difficulty label.
        public_key_hex (str): Hex-encoded Ed25519 public key.
    """
    difficulty: int
    public_key_hex: str

    @timed
    def generate(self, seed: int) -> tuple[Problem, Verif]:
        problem = Problem(difficulty=self.difficulty)
        verif = Verif(public_key_hex=self.public_key_hex)
        return problem, verif

    @timed
    def verify(self, prob: Problem, sol: Solution, verif: Verif) -> bool:
        if sol.signature is None or sol.payload is None:
            _logger.info(
                "Verification FAILURE: signature or payload is None"
            )
            return False

        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                Ed25519PublicKey,
            )
        except ImportError:
            _logger.error(
                "cryptography package required for mock challenge verification"
            )
            return False

        # Check timestamp is within validity window
        try:
            payload_data = json.loads(sol.payload)
            ts = payload_data["ts"]
        except (json.JSONDecodeError, KeyError) as e:
            _logger.info(f"Verification FAILURE: invalid payload: {e}")
            return False

        now = time.time()
        age = abs(now - ts)
        if age > VALIDITY_WINDOW_SECONDS:
            _logger.info(
                f"Verification FAILURE: timestamp too old "
                f"({age:.0f}s > {VALIDITY_WINDOW_SECONDS}s)"
            )
            return False

        # Verify Ed25519 signature
        try:
            public_key = Ed25519PublicKey.from_public_bytes(
                bytes.fromhex(verif.public_key_hex)
            )
            public_key.verify(
                bytes.fromhex(sol.signature),
                sol.payload.encode("utf-8"),
            )
        except Exception as e:
            _logger.info(f"Verification FAILURE: invalid signature: {e}")
            return False

        _logger.info("Verification SUCCESS: valid signature, timestamp OK")
        return True


def sign_mock_payload(private_key_hex: str) -> Solution:
    """
    Sign a time-based payload with an Ed25519 private key.

    This is the "solver" for the mock challenge. Call this on the miner
    side (never inside the Docker container).

    Args:
        private_key_hex: Hex-encoded 32-byte Ed25519 private key.

    Returns:
        A Solution with the signature and payload filled in.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
    )

    payload = json.dumps({"ts": int(time.time()), "challenge": "mock"})
    private_key = Ed25519PrivateKey.from_private_bytes(
        bytes.fromhex(private_key_hex)
    )
    signature = private_key.sign(payload.encode("utf-8"))

    return Solution(
        status="success",
        signature=signature.hex(),
        payload=payload,
    )


def generate_keypair() -> tuple[str, str]:
    """
    Generate a new Ed25519 keypair.

    Returns:
        (private_key_hex, public_key_hex) -- both as hex strings.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
    )
    from cryptography.hazmat.primitives.serialization import (
        Encoding, PublicFormat, PrivateFormat, NoEncryption,
    )

    private_key = Ed25519PrivateKey.generate()
    private_bytes = private_key.private_bytes(
        Encoding.Raw, PrivateFormat.Raw, NoEncryption()
    )
    public_bytes = private_key.public_key().public_bytes(
        Encoding.Raw, PublicFormat.Raw
    )
    return private_bytes.hex(), public_bytes.hex()
