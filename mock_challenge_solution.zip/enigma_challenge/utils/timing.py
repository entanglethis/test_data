"""
utils.timing – Performance timing decorator

Provides the @timed decorator that:
- Logs the start and end of wrapped functions/methods
- Measures and reports wall-clock duration using time.perf_counter()
- Works on both free functions and instance methods
"""
import time
import logging
from functools import wraps

_logger = logging.getLogger(__name__)


def timed(func):
    """
    Logs start/end and duration of the wrapped function/method.
    Works on both free functions and instance methods.
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        # Try to get a meaningful source name
        if args and hasattr(args[0], '__class__'):
            source = args[0].__class__.__name__.upper()
        else:
            source = func.__module__.split('.')[-1].upper()

        name = func.__name__.upper()
        _logger.debug(f"{source}  Starting {name}...")

        result = func(*args, **kwargs)

        duration = time.perf_counter() - start
        _logger.debug(f"{source}  {name} completed in {duration:.3f} s")

        return result
    return wrapper
