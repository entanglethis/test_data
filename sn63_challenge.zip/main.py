# main.py
from time import sleep, time
from datetime import timedelta


def main():
	for i in range(5):
		print(f"Some logging idx {i}")
		sleep(timedelta(seconds=1).total_seconds())

	output_text = "Hello from inside the Docker container! 🐳"

	# Write output to a file
	with open("/output/output.txt", "w") as f:
		f.write(output_text)

	print("✅ Output written to /output/output.txt")


if __name__ == "__main__":
	main()
