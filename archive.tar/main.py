# main.py

def main():
    output_text = "Hello from inside the Docker container! 🐳"
    
    # Write output to a file
    with open("/output/output.txt", "w") as f:
        f.write(output_text)
    
    print("✅ Output written to /output/output.txt")

if __name__ == "__main__":
    main()
